<template>
    <div>
        <div class="swiper-wrapper">
            <div data-v-a818784e class="swiper-slide" role="group" aria-label="2 / 6">
                <ul data-v-a818784e class="slider2-box">
                    <li data-v-a818784e="">
                        <p data-v-a818784e="">
                            <router-link to="/shoprule">门店规则</router-link>
                        </p>
                        <p data-v-a818784e="">Store Rules</p>
                    </li>
                    <li data-v-a818784e="">
                        <p data-v-a818784e="">
                            <router-link to="/emploerhobby">员工偏好</router-link>
                        </p>
                        <p data-v-a818784e="">Employee Preferences</p>
                    </li>
                    <li data-v-a818784e="">
                        <p data-v-a818784e="">
                            <router-link to="/paiban">排班表</router-link>
                        </p>
                        <p data-v-a818784e="">Schedule</p>
                    </li>
                    <li data-v-a818784e="">
                        <p data-v-a818784e="">
                            <router-link to="/chart">客流量</router-link>
                        </p>
                        <p data-v-a818784e="">Passenger Flow</p>
                    </li>
                    <li data-v-a818784e="">
                        <p data-v-a818784e="">
                            <router-link to="">关于我们</router-link>
                        </p>
                        <p data-v-a818784e="">About we</p>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>
<style>
@import url('@/assets/css/MianMiddle.css');
.slider2-box li:nth-child(1){
    background: url('@/assets/OIP-C.jpg') no-repeat;
}
.slider2-box li:nth-child(2){
    background: url('@/assets/home-slider2-1.c58a2da7.png') no-repeat;
}
.slider2-box li:nth-child(3){
    background: url('@/assets/home-slider2-4.2131a6bc.png') no-repeat;
}
.slider2-box li:nth-child(4){
    background: url('@/assets/R-C.jpg') no-repeat;
}
.slider2-box li:nth-child(5){
    background: url('@/assets/1080-x-1920-Image-Vertical-Free-Download.jpg') no-repeat;
}
</style>

