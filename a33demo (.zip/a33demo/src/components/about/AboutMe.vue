<template>
    <div>
        <div class="jumplinkmore">
            <el-button type="info" plain><a href=" http://175.178.131.223:8400/swagger-ui/index.html#/"
                    target="_blank">paiban服务接口文档</a></el-button>
            <el-button type="info" plain><a href=" http://43.138.133.120:9191/swagger-ui/index.html#/"
                    target="_blank">schedule-service服务接口文档</a></el-button>
            <el-button type="info" plain><a
                    href=" http://175.178.131.223:8848/nacos/index.html#/serviceManagement?dataId=&group=&appName=&namespace=&pageSize=&pageNo="
                    target="_blank">NACOS管理界面</a></el-button>
        </div>
    </div>
</template>
<style src="@/components/about/css/index.css"></style>
